﻿global using Serilog;
global using Serilog.Events;
